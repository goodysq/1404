# a
for i in range(11):
    number = i * 10
    print(number, end=' ')
print()

# b
for i in range(20, 0, -1):
    print(i, end=' ')
print()

# c
num_stars = int(input("Number of stars: "))
for i in range(num_stars):
    print("*", end=' ')
print()

# d
for i in range(1, num_stars + 1):
    print('*' * i)
print()
